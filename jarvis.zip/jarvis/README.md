# Jarvis — Groq + CrewAI (Skill Learning)

Repo: **farrukh_resarch-ai**

Command do → multi-agent research → optional skill save in `skills/` → expert-style answer.

| Item | Value |
|------|--------|
| API | Groq (https://console.groq.com) |
| Secret name | `groq_api_key` (lowercase) |
| Default model | `llama-3.3-70b-versatile` |
| Mobile | GitHub app → Issues comment ya Actions |

---

## Step 1 — Groq key

1. https://console.groq.com → API Keys → Create  
2. Key copy karo (`gsk_...`)

## Step 2 — GitHub secret (repo: farrukh_resarch-ai)

1. Repo → **Settings → Secrets and variables → Actions**  
2. **New repository secret**  
3. Name: `groq_api_key`  
4. Value: aapki `gsk_...` key  
5. Save  

## Step 3 — Code push

Is `jarvis` project ko apni repo root par rakho (ya merge), phir:

```bash
git add .
git commit -m "Add Jarvis Groq + CrewAI"
git push
```

Expected layout:

```text
farrukh_resarch-ai/
  .github/workflows/jarvis.yml
  requirements.txt
  src/jarvis/
  skills/
  README.md
```

## Step 4 — Mobile se chalao (asaan)

### A) Issue comment

1. Phone → GitHub app → `farrukh_resarch-ai`  
2. **Issues** → New issue (title: Jarvis)  
3. Comment:

```text
/jarvis learn Python asyncio production
```

ya

```text
/jarvis React performance checklist do
```

4. **Actions** tab dekho — workflow chalega  
5. Issue pe jawab aa jayega  
6. Skill bani to `skills/` auto-commit ho sakti hai  

### B) Actions → Run workflow

1. **Actions** → **jarvis** → **Run workflow**  
2. Prompt likho → Run  

## Step 5 — Laptop (optional)

```bash
cd farrukh_resarch-ai
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# .env: groq_api_key=gsk_xxxx

export PYTHONPATH=src
python -m jarvis.cli learn "React performance"
python -m jarvis.cli ask "App slow hai kya karun?"
python -m jarvis.cli chat
```

---

## Commands

| Local CLI | Issue comment |
|-----------|----------------|
| `python -m jarvis.cli ask "..."` | `/jarvis ...` |
| `python -m jarvis.cli learn "topic"` | `/jarvis learn topic` |
| `python -m jarvis.cli skills` | (local only) |
| `python -m jarvis.cli chat` | (local only) |

---

## CrewAI (already included)

4 agents sequential crew:

1. **Router** — intent  
2. **Researcher** — research  
3. **Skill Architect** — writes `SKILL.md`  
4. **Expert** — final answer  

Expand: `src/jarvis/crews/` mein naya module.

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Missing API key | Secret name exact `groq_api_key` |
| Workflow not run | Comment mein `/jarvis` hona chahiye |
| Cannot push skills | Settings → Actions → Workflow permissions → Read and write |
| Rate limit | Wait / use `llama-3.1-8b-instant` |

Skills = files on Git, not model training.
