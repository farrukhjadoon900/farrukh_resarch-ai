"""Jarvis — expandable multi-agent assistant with skill learning (CrewAI + Grok)."""

__version__ = "0.1.0"
